<?php


$string="The number of facilitators needed in the training of farmers in each production cluster,
        	 including SCPZ catchment areas where feasible, would be based on the number of farmers 
        	 that a facilitator could service with adequate attention paid to gender inclusiveness.
         It was agreed that Facilitators and Community Development Officers (CDOs) will be engaged for a maximum of 2 years
          of the project period for the purpose of facilitating the preparation of business plans for participating farmers 
          consisting of FUGs, out-growers, contract farmers and nucleus farms. 
          Capacity building will be provided for Facilitators, Services Providers, FUGs, 
          FCAs and other Producer Associations. Approval of the business plans that will be developed, 
          to take advantage of opportunities of market demand with strong linkage with private sector, 
          will be carried out at the cluster level.";
		  
 //$word = str_word_count($s);
 //$dby2=round($word/2);
	
// 
//$string='this is a long text string where it is writt.en something';
$substring = substr($string,0, strpos($string,'.'));
// var_dump($output);	

//$stringSentence = "The quick brown fox jumps over the lazy dog";
// $word = str_word_count($s);
 // $tdby2=round($word/2);	
// 
//  
//  
//  
 // $buffer = '';
// $count = 1;
// $length = strlen($s);
// $dby2=round($length/2);
// 
// // 
// // 
// for ($i = 0; $i < $dby2; $i++) {
//    
    // if ($s{$i} !== ' ') {
        // $buffer .= $s{$i};
    // } else {
        // echo$buffer . ' ';
        // $buffer = '';
    // }
//     
// }
// echo$buffer;  
?>